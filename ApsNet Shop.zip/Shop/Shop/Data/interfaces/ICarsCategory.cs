﻿using System;
using System.Collections.Generic;
using System.Linq;
using Shop.Data.Models;
using System.Threading.Tasks;

namespace Shop.Data.interfaces
{
    public interface ICarsCategory
    {
        IEnumerable<Category> AllCategories { get; }
    }
}
